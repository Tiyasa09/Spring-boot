package com.springrest.Springrst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrstApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrstApplication.class, args);
	}

}
